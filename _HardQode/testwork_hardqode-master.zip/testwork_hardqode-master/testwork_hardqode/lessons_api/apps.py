from django.apps import AppConfig


class LessonsApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lessons_api'
